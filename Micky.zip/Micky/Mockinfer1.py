# ------------------------
# PART A: Imports & Setup
# ------------------------
import os
import gymnasium as gym
from gymnasium import spaces
import numpy as np
import pandas as pd
from ta import trend, momentum, volatility, volume
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.backends.backend_pdf import PdfPages
import yfinance as yf

from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import SubprocVecEnv
from stable_baselines3.common.vec_env import VecNormalize
from stable_baselines3.common.env_checker import check_env
from stable_baselines3.common.callbacks import CheckpointCallback, BaseCallback, CallbackList

import torch
import warnings
from typing import Optional, Tuple
import random
import datetime
import math
import logging
from pathlib import Path
import optuna
import joblib
#import time
import plotly.io as pio
import traceback
import pytz

from datetime import datetime, time as dtime, timedelta
from kiteconnect import KiteConnect, KiteTicker

from ta.momentum import StochasticOscillator
from ta.volume import ChaikinMoneyFlowIndicator, OnBalanceVolumeIndicator, ForceIndexIndicator
from ta.volatility import KeltnerChannel

try:
    from concurrent_log_handler import ConcurrentRotatingFileHandler
except ImportError:
    raise ImportError("Please install 'concurrent-log-handler' package via pip: pip install concurrent-log-handler")

warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)
torch.manual_seed(RANDOM_SEED)

BASE_DIR = Path('.').resolve()
RESULTS_DIR = BASE_DIR / 'results'
PLOTS_DIR = BASE_DIR / 'plots'
TB_LOG_DIR = BASE_DIR / 'tensorboard_logs'
RESULTS_DIR.mkdir(parents=True, exist_ok=True)
PLOTS_DIR.mkdir(parents=True, exist_ok=True)
TB_LOG_DIR.mkdir(parents=True, exist_ok=True)

def setup_logger(name: str, log_file: Path, level=logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(level)
    if not logger.handlers:
        handler = ConcurrentRotatingFileHandler(str(log_file), maxBytes=10**6, backupCount=300, encoding='utf-8')
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    return logger

main_logger = setup_logger('main_logger', RESULTS_DIR / 'main.log', level=logging.DEBUG)
training_logger = setup_logger('training_logger', RESULTS_DIR / 'training.log', level=logging.DEBUG)
testing_logger = setup_logger('testing_logger', RESULTS_DIR / 'testing.log', level=logging.DEBUG)
phase_logger = setup_logger('phase_logger', RESULTS_DIR / 'phase.log', level=logging.INFO)
ws_logger = setup_logger('ws_logger', RESULTS_DIR / 'websocket.log', level=logging.DEBUG)

def log_phase(phase: str, status: str = "Starting", env_details: dict = None, duration: float = None):
    log_message = f"***** {status} {phase} *****"
    if env_details:
        log_message += f"\nEnvironment Details: {env_details}"
    if duration is not None:
        log_message += f"\nDuration: {duration:.2f} seconds ({duration/60:.2f} minutes)"
    phase_logger.info(log_message)

# Define this ONCE at the start
current_dt = datetime.now(pytz.timezone("Asia/Kolkata"))
cutoff_time = (current_dt + timedelta(minutes=25)).time()

# ---------------------------------
# PART B: KiteConnect Setup & Auth
# ---------------------------------
import requests
import pyotp
from urllib.parse import urlparse, parse_qs
from kiteconnect import KiteConnect

API_KEY = "gqi9lxf3meq6iiwa"
API_SECRET = "x25qsv88ig4mce1e4037r7pn8ajofr02"
USERNAME = "KY4369"
PASSWORD = "Maligai321!"
TOTP_KEY = "XZ2SZ5L4CQDGAHYZQVMPDZQERZOOV3UF"  # Base32 format

kite = KiteConnect(api_key=API_KEY)

def get_access_token():
    session = requests.Session()

    # 1. Basic login
    login_resp = session.post(
        "https://kite.zerodha.com/api/login",
        data={"user_id": USERNAME, "password": PASSWORD},
    )
    request_id = login_resp.json()["data"]["request_id"]

    # 2. TOTP 2FA
    session.post(
        "https://kite.zerodha.com/api/twofa",
        data={
            "user_id": USERNAME,
            "request_id": request_id,
            "twofa_value": pyotp.TOTP(TOTP_KEY).now(),
        },
    )

    # 3. Follow redirects until we find ?request_token=...
    next_url = f"https://kite.trade/connect/login?api_key={API_KEY}"
    for _ in range(10):  # Up to 10 hops
        r = session.get(next_url, allow_redirects=False)
        location = r.headers.get("Location", "")
        parsed = urlparse(location)
        qs = parse_qs(parsed.query)
        if "request_token" in qs:
            request_token = qs["request_token"][0]
            # 4. Generate the access token
            data = kite.generate_session(request_token, api_secret=API_SECRET)
            return data["access_token"]
        if not location:
            raise RuntimeError("No Location header – stopped early.")
        next_url = location

    raise RuntimeError("No request_token found after multiple redirects.")

# Get dump of all NSE instruments using Kite
instrument_dump = kite.instruments("NSE")
instrument_df = pd.DataFrame(instrument_dump)

def get_instrument_token(ticker: str, instrument_df: pd.DataFrame) -> Optional[int]:
    token_series = instrument_df.loc[instrument_df["tradingsymbol"] == ticker, "instrument_token"]
    if not token_series.empty:
        return int(token_series.iloc[0])
    else:
        return None

def get_ticker_from_token(instrument_token: int, instrument_df: pd.DataFrame) -> Optional[str]:
    token_series = instrument_df.loc[instrument_df["instrument_token"] == instrument_token, "tradingsymbol"]
    if not token_series.empty:
        return str(token_series.iloc[0])
    else:
        return None

# --------------------------------------------------------------------
# PART C: Kite Websocket Data Fetcher (KiteWSDataFetcher) with IST
# --------------------------------------------------------------------
import threading
import time
import pytz
import csv
from datetime import datetime, timedelta

def generate_synthetic_ticks(
    instrument_token=492033,
    start_price=1700.0,
    start_volume=100000,
    tick_count=100,
    tick_spacing_seconds=180
):
    """
    Generate a list of dictionaries representing synthetic ticks, 
    e.g. simulating a small random walk around `start_price`.
    """
    now_ist = datetime.now(pytz.timezone("Asia/Kolkata"))
    price = start_price
    volume = start_volume
    ticks = []
    
    for i in range(tick_count):
        # small random walk for last_price
        price_change = random.uniform(-1.0, 1.0)
        price = max(1.0, price + price_change)
        
        # random volume increment
        volume += random.randint(0, 100)
        
        # each tick is spaced some seconds apart
        tick_time = now_ist + timedelta(seconds=i * tick_spacing_seconds)
        
        ticks.append({
            "instrument_token": instrument_token,
            "last_price": price,
            "volume_traded": volume,
            "last_trade_time": tick_time
        })
    return ticks
# If you have the original aggregator code in a parent class, import it:
# from your_code import KiteWSDataFetcher

class MockKiteWSDataFetcher:
    """
    A mock data fetcher that simulates live ticks from memory (or from a CSV).
    It mimics the same interface as the real KiteWSDataFetcher but does not connect
    to any external websocket. Instead, it feeds tick data in a background thread.
    """

    def __init__(self,
                 instrument_token,
                 bucket_minutes=3,
                 ticker: str = None,
                 mock_ticks=None,
                 tick_interval_sec=1.0):
        """
        :param instrument_token: Same usage as real fetcher, for compatibility
        :param bucket_minutes:   The aggregator bucket size in minutes
        :param ticker:           Optional string name
        :param mock_ticks:       A list of dicts, each representing one tick. 
                                 E.g. [{'last_price':..., 'volume_traded':..., 'last_trade_time':...}, ...]
        :param tick_interval_sec: How many real-time seconds to wait between feeding each tick
        """
        self.instrument_token = instrument_token
        self.bucket_minutes = bucket_minutes
        self.ticker = ticker if ticker else str(instrument_token)
        self.ticker = get_ticker_from_token(self.instrument_token, instrument_df)
        self.ist = pytz.timezone("Asia/Kolkata")
        self.ticker_log_file = str(RESULTS_DIR / f"{self.ticker}_ticks.csv")
        self.agg_log_file = str(RESULTS_DIR / f"{self.ticker}_agg.csv")

        self.mock_ticks = mock_ticks if mock_ticks else []
        self.tick_interval_sec = tick_interval_sec

        # aggregator dict: { bucket_start: { open, high, low, close, base_volume, volume } }
        self.aggregator = {}
        self.aggregated_bar = None

        # We replicate the 'new_bar_event' threading event from the real fetcher.
        self.new_bar_event = threading.Event()
        # We'll also replicate last_finalized_time, lock, etc.
        self.last_finalized_time = None
        self._stop_signal = False
        self.lock = threading.Lock()

        # Typically you'd have log file logic, but we just skip or mock it.
        self.ticker_log_file = None
        self.agg_log_file = None

        # This will be the background thread that “plays” the ticks.
        self.thread = None

    def start(self):
        """
        Instead of connecting to the real Kite Ticker, we spawn a thread to feed mock ticks.
        """
        self._stop_signal = False
        self.thread = threading.Thread(target=self._feed_mock_data, daemon=True)
        self.thread.start()

    def stop(self):
        """
        Signal the background thread to stop.
        """
        self._stop_signal = True
        if self.thread is not None:
            self.thread.join(timeout=5)

    def get_latest_bar(self):
        """
        Return the last finalized bar from aggregator.
        """
        with self.lock:
            return self.aggregated_bar

    ################################################################################
    # SUGGESTION BLOCK 1: Add aggregator logs in _feed_mock_data() and _finalize_buckets()
    ################################################################################

    def _feed_mock_data(self):
        """
        Continuously feed ticks from `self.mock_ticks` into the aggregator,
        waiting `tick_interval_sec` between each.
        """
        for i, tick in enumerate(self.mock_ticks):
            if self._stop_signal:
                break
            ws_logger.debug(f"[MockData] Feeding tick #{i} for {self.ticker}: {tick}")
            
            self._on_tick(tick)
            time.sleep(self.tick_interval_sec)

    def _on_tick(self, tick):
        """
        The aggregator logic is essentially the same as on_ticks() in the real fetcher.
        We pretend we got exactly 1 tick at a time from the “websocket”.
        """
        with self.lock:
            tick_time = tick["last_trade_time"]
            # Ensure tick_time is an aware datetime in IST
            if tick_time.tzinfo is None:
                tick_time = self.ist.localize(tick_time)
            else:
                tick_time = tick_time.astimezone(self.ist)

            # Skip stale ticks if we have a last finalized time:
            if self.last_finalized_time is not None and tick_time <= self.last_finalized_time:
                return  # ignore stale

            # Update aggregator
            bucket_start = self._get_bucket_start(tick_time, self.bucket_minutes)
            if bucket_start not in self.aggregator:
                self.aggregator[bucket_start] = {
                    "open": tick["last_price"],
                    "high": tick["last_price"],
                    "low": tick["last_price"],
                    "close": tick["last_price"],
                    "base_volume": tick["volume_traded"],
                    "volume": 0
                }
            else:
                agg = self.aggregator[bucket_start]
                price = tick["last_price"]
                agg["high"] = max(agg["high"], price)
                agg["low"] = min(agg["low"], price)
                agg["close"] = price
                # update volume if new volume is higher
                new_volume = tick["volume_traded"] - agg["base_volume"]
                if new_volume > agg.get("volume", 0):
                    agg["volume"] = new_volume

            # Possibly finalize older buckets
            self._finalize_buckets(tick_time)

    def _finalize_buckets(self, current_tick_time: datetime):
        current_bucket_start = self._get_bucket_start(current_tick_time, self.bucket_minutes)
        buckets_to_remove = []
        for bkt in list(self.aggregator.keys()):
            if bkt + timedelta(minutes=self.bucket_minutes) <= current_bucket_start:
                agg = self.aggregator[bkt]
                agg["bucket_start"] = bkt
                self.aggregated_bar = agg

                # OPTIONAL: If you want to log each bar to CSV or logs:
                self._log_aggregated_bar(agg)

                ws_logger.info(
                    f"[MockData] Finalized bar for {self.ticker}, start={bkt}, O={agg['open']}, "
                    f"H={agg['high']}, L={agg['low']}, C={agg['close']}, Vol={agg['volume']}"
                )

                # Mark that a new bar is ready
                self.new_bar_event.set()
                self.new_bar_event.clear()
                self.last_finalized_time = bkt
                buckets_to_remove.append(bkt)

        for bkt in buckets_to_remove:
            del self.aggregator[bkt]

    @staticmethod
    def _get_bucket_start(dt, bucket_minutes):
        dt = dt.replace(second=0, microsecond=0)
        minute = (dt.minute // bucket_minutes) * bucket_minutes
        return dt.replace(minute=minute, second=0, microsecond=0)

    # The real code uses these callbacks. We just stub them:
    def on_connect(self, ws, response):
        pass
    def on_close(self, ws, code, reason):
        pass
    def on_error(self, ws, error):
        pass

    def _log_tick(self, tick: dict):
        # Ensure self.ticker_log_file is defined
        if not self.ticker_log_file:
            self.ticker_log_file = str(RESULTS_DIR / f"{self.ticker}_mock_ticks.csv")

        fieldnames = list(tick.keys())
        # Define write_header now that we know ticker_log_file is a real path
        write_header = not os.path.exists(self.ticker_log_file)

        try:
            with open(self.ticker_log_file, mode="a", newline="") as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                if write_header:
                    writer.writeheader()
                tick_to_log = tick.copy()
                if isinstance(tick_to_log.get("last_trade_time"), datetime):
                    tick_to_log["last_trade_time"] = tick_to_log["last_trade_time"].strftime("%Y-%m-%d %H:%M:%S")
                writer.writerow(tick_to_log)

            ws_logger.debug(f"[WS] Logged tick for {self.ticker}")
        except Exception as e:
            ws_logger.error(f"[WS] Error logging tick: {e}")


    def _log_aggregated_bar(self, agg: dict):
        # Ensure self.agg_log_file is defined
        if not self.agg_log_file:
            self.agg_log_file = str(RESULTS_DIR / f"{self.ticker}_mock_agg.csv")

        fieldnames = ["bucket_start", "open", "high", "low", "close", "volume"]
        # Check if file exists to decide header
        write_header = not os.path.exists(self.agg_log_file)

        try:
            with open(self.agg_log_file, mode="a", newline="") as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                # Write the header only if this file doesn't exist yet
                if write_header:
                    writer.writeheader()

                agg_to_log = {
                    "bucket_start": agg.get("bucket_start").strftime("%Y-%m-%d %H:%M:%S") 
                                    if agg.get("bucket_start") else "",
                    "open": agg.get("open", 0),
                    "high": agg.get("high", 0),
                    "low": agg.get("low", 0),
                    "close": agg.get("close", 0),
                    "volume": agg.get("volume", 0)
                }
                writer.writerow(agg_to_log)

            ws_logger.debug(f"[WS] Logged aggregated bar for {self.ticker}")
        except Exception as e:
            ws_logger.error(f"[WS] Error logging aggregated bar: {e}")


# -------------------------------------------------
# PART D: get_data_kite with IST (historical_data)
# -------------------------------------------------
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta
from ta import trend, momentum, volatility, volume

def get_data_kite(kite, instrument_token: int = 464385, days: int = 5, interval: str = "15minute") -> pd.DataFrame:
    """
    Fetch intraday data from the KiteConnect API for the given instrument_token,
    using the specified interval and number of days, then perform the same
    validations and technical indicator calculations as your original function.
    """
    date_string_format = "%Y-%m-%d %H:%M:%S"
    
    to_date_obj = datetime.now(pytz.timezone("Asia/Kolkata"))  # Ensure we always use IST "now"
    from_date_obj = to_date_obj - timedelta(days=days)

    to_date_str = to_date_obj.strftime(date_string_format)
    from_date_str = from_date_obj.strftime(date_string_format)

    try:
        data = kite.historical_data(
            instrument_token=instrument_token,
            from_date=from_date_str,
            to_date=to_date_str,
            interval=interval
        )
    except Exception as e:
        print(f"Error fetching data from KiteConnect: {e}")
        return pd.DataFrame()

    if not data:
        print(f"No data returned from KiteConnect for token {instrument_token}.")
        return pd.DataFrame()

    df = pd.DataFrame(data)
    df.rename(columns={
        "date": "Date",
        "open": "Open",
        "high": "High",
        "low": "Low",
        "close": "Close",
        "volume": "Volume"
    }, inplace=True)

    if "Adj Close" not in df.columns:
        df["Adj Close"] = df["Close"]

    required_columns = ["Date", "Open", "High", "Low", "Close", "Volume", "Adj Close"]
    for col in ["Date", "Open", "High", "Low", "Close", "Volume"]:
        if col not in df.columns:
            print(f"[get_data_kite] Missing required column '{col}'.")
            return pd.DataFrame()

    # Make them all datetime in UTC, then convert to IST
    try:
        df["Date"] = pd.to_datetime(df["Date"], utc=True)
        df["Date"] = df["Date"].dt.tz_convert("Asia/Kolkata")
    except Exception as e:
        print(f"[get_data_kite] Could not parse 'Date' column: {e}")
        df["Date"] = np.arange(len(df))

    df.sort_values("Date", inplace=True)
    df.reset_index(drop=True, inplace=True)

    numeric_cols = ["Open", "High", "Low", "Close", "Adj Close", "Volume"]
    df[numeric_cols] = df[numeric_cols].apply(pd.to_numeric, errors="coerce")

    if len(df) < 5:
        print(f"[get_data_kite] Not enough data points ({len(df)}) for token {get_ticker_from_token(instrument_token, instrument_df)}. Need >= 5.")
        return pd.DataFrame()

    try:
        if "minute" in interval or "hour" in interval:
            sma_short_window = 3
            sma_long_window = 9
            rsi_window = 7
            adx_window = 7
            bollinger_window = 10
            ema_window = 5
        else:
            sma_short_window = 10
            sma_long_window = 50
            rsi_window = 14
            adx_window = 14
            bollinger_window = 20
            ema_window = 20

        close = df["Close"]
        high = df["High"]
        low = df["Low"]
        vol_series = df["Volume"]

        df['Log_Close'] = np.log(df['Close'])
        df['Log_Return'] = df['Log_Close'].diff().fillna(0)

        df["SMA10"] = trend.SMAIndicator(close=close, window=sma_short_window).sma_indicator()
        df["SMA50"] = trend.SMAIndicator(close=close, window=sma_long_window).sma_indicator()
        df["RSI"] = momentum.RSIIndicator(close=close, window=rsi_window).rsi()
        df["MACD"] = trend.MACD(close=close).macd()
        df["ADX"] = trend.ADXIndicator(high=high, low=low, close=close, window=adx_window).adx()
        bollinger = volatility.BollingerBands(close=close, window=bollinger_window, window_dev=2)
        df["BB_Upper"] = bollinger.bollinger_hband()
        df["BB_Lower"] = bollinger.bollinger_lband()
        df["Bollinger_Width"] = bollinger.bollinger_wband()
        df["EMA20"] = trend.EMAIndicator(close=close, window=ema_window).ema_indicator()
        df["VWAP"] = volume.VolumeWeightedAveragePrice(
            high=high, low=low, close=close, volume=vol_series, window=14
        ).volume_weighted_average_price()
        df["Lagged_Return"] = close.pct_change().fillna(0)
        df["Volatility"] = volatility.AverageTrueRange(
            high=high, low=low, close=close, window=adx_window
        ).average_true_range()

        df['HourOfDay'] = df['Date'].dt.hour
        df['MinuteOfHour'] = df['Date'].dt.minute
        df['DayOfWeek'] = df['Date'].dt.dayofweek
        df['Lag_Return_1'] = df['Close'].pct_change(1).fillna(0)
        df['Lag_Return_2'] = df['Close'].pct_change(2).fillna(0)
        df['Volume_Change_1'] = df['Volume'].pct_change(1).fillna(0)
        df['Volume_RollRatio'] = (df['Volume'] / df['Volume'].rolling(5).mean()).fillna(1)
        df['Intraday_Range'] = df['High'] - df['Low']
        df['Intraday_Range_Pct'] = (df['High'] - df['Low']) / (df['Close'] + 1e-9)

        # Assume the exchange day starts at 09:15
        df['MinutesSinceOpen'] = (
            df['Date'] - df['Date'].dt.normalize() - pd.Timedelta("9h15m")
        ).dt.total_seconds() / 60
        df['MinutesSinceOpen'] = df['MinutesSinceOpen'].clip(lower=0)
    except Exception as e:
        print(f"[get_data_kite] Error calculating indicators: {e}")
        return pd.DataFrame()

    df.fillna(method="ffill", inplace=True)
    df.fillna(0, inplace=True)

    RESULTS_DIR = Path("./results")
    RESULTS_DIR.mkdir(exist_ok=True, parents=True)
    csv_path = RESULTS_DIR / f"data_fetched_{get_ticker_from_token(instrument_token, instrument_df)}.csv"
    try:
        df.to_csv(csv_path, index=False)
        print(f"Data successfully saved to: {csv_path}")
    except Exception as e:
        print(f"[get_data_kite] Failed to write CSV: {e}")

    print(df.head(5))
    return df



# ------------------------------------------------------------
# PART E: SingleStockTradingEnv (with IST in _update_live_data)
# ------------------------------------------------------------
FEATURES_TO_SCALE = [
    "Close", "SMA10", "SMA50", "RSI", "MACD", "ADX",
    "BB_Upper", "BB_Lower", "Bollinger_Width", "EMA20", "VWAP", 
    "Lagged_Return", "Volatility", "Volume",
    "Lag_Return_1", "Lag_Return_2",
    "Volume_Change_1", "Volume_RollRatio",
    "Intraday_Range", "Intraday_Range_Pct",
    "HourOfDay", "MinuteOfHour", "DayOfWeek",
    "MinutesSinceOpen",
]

LOG_TRANSFORM_FEATURES = ["Close", "Volume"]

class SingleStockTradingEnv(gym.Env):
    metadata = {'render.modes': ['human']}

    def __init__(
        self,
        df: pd.DataFrame,
        ticker: str,
        kite: KiteConnect,
        initial_balance: float = 100000,
        stop_loss: float = 0.90,
        take_profit: float = 1.10,
        max_position_size: float = 0.5,
        max_drawdown: float = 0.20,
        annual_trading_days: int = 252,
        transaction_cost: float = 0.0001,
        env_rank: int = 0,
        some_factor: float = 0.01,
        hold_threshold: float = 0.1, 
        reward_weights: Optional[dict] = None,
        trailing_drawdown_trigger: float = 0.20,
        trailing_drawdown_grace: int = 3,
        forced_liquidation_penalty: float = -5.0,
        max_episode_steps: Optional[int] = None,
        mode: str = "train",
        inference_buy_threshold: float = 0.5,
        inference_sell_threshold: float = 0.5
    ):
        super(SingleStockTradingEnv, self).__init__()
        self.env_rank = env_rank
        self.ticker = ticker
        self.kite = kite

        self.df = df.copy().reset_index(drop=True)
        self.instrument_token = get_instrument_token(self.ticker, instrument_df)

        self.initial_balance = initial_balance
        self.stop_loss = stop_loss
        self.take_profit = take_profit
        self.max_position_size = max_position_size
        self.max_drawdown = max_drawdown
        self.annual_trading_days = annual_trading_days
        self.transaction_cost = transaction_cost
        self.some_factor = some_factor
        self.hold_threshold = hold_threshold
        self.trailing_drawdown_trigger = trailing_drawdown_trigger
        self.trailing_drawdown_grace = trailing_drawdown_grace
        self.forced_liquidation_penalty = forced_liquidation_penalty
        self.current_obs_dict = {}

        if max_episode_steps is None:
            self.max_episode_steps = min(1000, len(self.df))
        else:
            self.max_episode_steps = max_episode_steps

        self.mode = mode  
        self.inference_buy_threshold = inference_buy_threshold
        self.inference_sell_threshold = inference_sell_threshold
        self.profit_reference = initial_balance
        self.realized_gain = 0.0

        main_logger.info(f"[Env {self.env_rank}] Inference Buy Threshold set to {self.inference_buy_threshold}, "
                         f"Inference Sell Threshold set to {self.inference_sell_threshold}")

        import collections
        self.reward_history = collections.deque(maxlen=500)

        self.action_space = spaces.Box(low=-1, high=1, shape=(1,), dtype=np.float32)
        self.num_features = len(FEATURES_TO_SCALE)
        self.market_phase = ['Bull', 'Bear', 'Sideways']

        self.observation_space = spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(self.num_features + 3 + len(self.market_phase) + 5,),
            dtype=np.float32
        )

        if reward_weights is not None:
            self.reward_weights = reward_weights
        else:
            self.reward_weights = {'reward_scale': 1.0}

        self.cumulative_reward = 0.0
        self._force_termination = False
        self.final_metrics = None

        self.current_step = 0
        self.history = []
        self.prev_net_worth = initial_balance
        self.last_action = 0.0
        self.peak = initial_balance
        self.returns_window = []
        self.transaction_count = 0
        self.consecutive_drawdown_steps = 0

        self.bucket_minutes = 0.25

        mock_ticks = generate_synthetic_ticks(
            instrument_token=get_instrument_token(ticker, instrument_df),
            start_price=random.uniform(500, 2000),
            start_volume=random.uniform(50000, 100000),
            tick_count=500,          # how many ticks to simulate
            tick_spacing_seconds=10 # each tick 5s apart
        )

        self.data_fetcher = MockKiteWSDataFetcher(
            instrument_token=get_instrument_token(ticker, instrument_df),
            bucket_minutes=1,
            ticker=self.ticker,
            mock_ticks=mock_ticks,
            tick_interval_sec=10   # feed a new tick every 10 second in real-time
        )
        self.data_fetcher.start()

        self.reset()

    def seed(self, seed=None):
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        training_logger.debug(f"[Env {self.env_rank}] Seed set to {seed}")

    def _update_live_data(self):
        """
        Check for a new aggregated bar from the websocket.
        If available, append it to self.df as an IST-aware timestamp.
        """
         # Wait for a new bar; set a timeout (e.g., 900 seconds for 15 minutes).
        ws_logger.info("[Inference] Waiting for new aggregated bar event...")
        if not self.data_fetcher.new_bar_event.wait(timeout=1000):
            # Timeout occurred. You can either return a default observation or handle as needed.
            default_obs = np.zeros(self.observation_space.shape[0], dtype=np.float32)
            training_logger.warning(f"[Env {self.env_rank}] Timeout waiting for new bar; returning default observation.")
            return default_obs
        ws_logger.info("[Inference] New aggregated bar event received.")
        # Clear the event for next time.
        self.data_fetcher.new_bar_event.clear()
        # Append the new aggregated bar to self.df.
        new_bar = self.data_fetcher.get_latest_bar()
        if new_bar is not None:
            bar_row = {
                "Date": datetime.now(pytz.timezone("Asia/Kolkata")),
                "Open": new_bar["open"],
                "High": new_bar["high"],
                "Low": new_bar["low"],
                "Close": new_bar["close"],
                "Volume": new_bar["volume"]
            }
            new_df = pd.DataFrame([bar_row])
            self.df = pd.concat([self.df, new_df], ignore_index=True)
            training_logger.info(
                f"[Env {self.env_rank}] Appended new bar. df length now={len(self.df)}"
            )

    def _compute_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Compute technical indicators on the provided DataFrame.
        This function assumes the DataFrame has at least the following columns:
        "Date", "Open", "High", "Low", "Close", "Volume". If "Adj Close" is not present,
        it is added as a copy of "Close". The function converts dates to IST,
        computes indicators (SMA, RSI, MACD, ADX, Bollinger Bands, EMA20, VWAP, etc.),
        and appends additional features. Finally, it writes the result to a CSV file.
        """
        # Standardize column names.
        df.rename(columns={
            "date": "Date",
            "open": "Open",
            "high": "High",
            "low": "Low",
            "close": "Close",
            "volume": "Volume"
        }, inplace=True)

        if "Adj Close" not in df.columns:
            df["Adj Close"] = df["Close"]

        # Check required columns.
        required_columns = ["Date", "Open", "High", "Low", "Close", "Volume", "Adj Close"]
        for col in ["Date", "Open", "High", "Low", "Close", "Volume"]:
            if col not in df.columns:
                print(f"[_compute_indicators] Missing required column '{col}'.")
                return pd.DataFrame()

        # Convert Date column to datetime in UTC and then to IST.
        try:
            df["Date"] = pd.to_datetime(df["Date"], utc=True)
            df["Date"] = df["Date"].dt.tz_convert("Asia/Kolkata")
        except Exception as e:
            print(f"[_compute_indicators] Could not parse 'Date' column: {e}")
            df["Date"] = np.arange(len(df))

        df.sort_values("Date", inplace=True)
        df.reset_index(drop=True, inplace=True)

        numeric_cols = ["Open", "High", "Low", "Close", "Adj Close", "Volume"]
        df[numeric_cols] = df[numeric_cols].apply(pd.to_numeric, errors="coerce")

        if len(df) < 5:
            print(f"[_compute_indicators] Not enough data points ({len(df)})")
            return pd.DataFrame()

        try:
            # Use shorter windows for intraday data.
            sma_short_window = 3
            sma_long_window = 9
            rsi_window = 7
            adx_window = 7
            bollinger_window = 10
            ema_window = 5

            close = df["Close"]
            high = df["High"]
            low = df["Low"]
            vol_series = df["Volume"]

            df['Log_Close'] = np.log(df['Close'])
            df['Log_Return'] = df['Log_Close'].diff().fillna(0)

            df["SMA10"] = trend.SMAIndicator(close=close, window=sma_short_window).sma_indicator()
            df["SMA50"] = trend.SMAIndicator(close=close, window=sma_long_window).sma_indicator()
            df["RSI"] = momentum.RSIIndicator(close=close, window=rsi_window).rsi()
            df["MACD"] = trend.MACD(close=close).macd()
            df["ADX"] = trend.ADXIndicator(high=high, low=low, close=close, window=adx_window).adx()

            bollinger = volatility.BollingerBands(close=close, window=bollinger_window, window_dev=2)
            df["BB_Upper"] = bollinger.bollinger_hband()
            df["BB_Lower"] = bollinger.bollinger_lband()
            df["Bollinger_Width"] = bollinger.bollinger_wband()

            df["EMA20"] = trend.EMAIndicator(close=close, window=ema_window).ema_indicator()
            df["VWAP"] = volume.VolumeWeightedAveragePrice(
                high=high, low=low, close=close, volume=vol_series, window=14
            ).volume_weighted_average_price()
            df["Lagged_Return"] = close.pct_change().fillna(0)
            df["Volatility"] = volatility.AverageTrueRange(
                high=high, low=low, close=close, window=adx_window
            ).average_true_range()

            df['HourOfDay'] = df['Date'].dt.hour
            df['MinuteOfHour'] = df['Date'].dt.minute
            df['DayOfWeek'] = df['Date'].dt.dayofweek
            df['Lag_Return_1'] = df['Close'].pct_change(1).fillna(0)
            df['Lag_Return_2'] = df['Close'].pct_change(2).fillna(0)
            df['Volume_Change_1'] = df['Volume'].pct_change(1).fillna(0)
            df['Volume_RollRatio'] = (df['Volume'] / df['Volume'].rolling(5).mean()).fillna(1)
            df['Intraday_Range'] = df['High'] - df['Low']
            df['Intraday_Range_Pct'] = (df['High'] - df['Low']) / (df['Close'] + 1e-9)

            # Assume the exchange day starts at 09:15 IST.
            df['MinutesSinceOpen'] = (
                df['Date'] - df['Date'].dt.normalize() - pd.Timedelta("9h15m")
            ).dt.total_seconds() / 60
            df['MinutesSinceOpen'] = df['MinutesSinceOpen'].clip(lower=0)
        except Exception as e:
            print(f"[_compute_indicators] Error calculating indicators: {e}")
            return pd.DataFrame()

        df.fillna(method="ffill", inplace=True)
        df.fillna(0, inplace=True)

        # Optionally, append the computed indicator data to a CSV file for verification.
        try:
            date_str = self.df['Date'].iloc[0].strftime('%Y%m%d')  # Safely extract the date string
            csv_path = RESULTS_DIR / f"live_indicators_{self.ticker}_{date_str}.csv"
            #csv_path = RESULTS_DIR / f"live_indicators_{self.ticker_df['Date'].iloc[0].strftime('%Y%m%d')}.csv"
            df.to_csv(csv_path, index=False)
            print(f"[Compute] Indicators successfully computed and saved to: {csv_path}")
        except Exception as e:
            print(f"[_compute_indicators] Failed to write indicators CSV: {e}")

        return df

    def _next_observation(self, fetch_aggregator: bool = True) -> np.ndarray:
        """
        (A) Optionally fetch a new bar from the aggregator if fetch_aggregator=True.
        (B) Ensure current_step is within df bounds.
        (C) Compute indicators, build the final observation array.
        (D) Return the observation array.
        """
        # -----------------------------
        # (A) Optionally fetch new raw bar data
        # -----------------------------
        if fetch_aggregator:
            ws_logger.info("[Inference] Attempting to fetch new bar from aggregator...")
            print(f"[Inference] Attempting to fetch new bar from aggregator...")
            got_bar = self.data_fetcher.new_bar_event.wait(timeout=300)  # e.g. 300s timeout
            if not got_bar:
                training_logger.warning(
                    f"[Env {self.env_rank}] Timeout in _next_observation; no new aggregator bar appended."
                )
                print(f"[Env {self.env_rank}] Timeout in _next_observation; no new aggregator bar appended.")
            else:
                ws_logger.info("[Inference] New aggregated bar event received in _next_observation.")
                print(f"[Inference] New aggregated bar event received in _next_observation.")
                self.data_fetcher.new_bar_event.clear()
                new_bar = self.data_fetcher.get_latest_bar()
                if new_bar is not None:
                    # Build a raw bar dictionary from the new tick data
                    raw_bar = {
                        "Date": datetime.now(pytz.timezone("Asia/Kolkata")),
                        "Open": new_bar["open"],
                        "High": new_bar["high"],
                        "Low": new_bar["low"],
                        "Close": new_bar["close"],
                        "Volume": new_bar["volume"]
                    }
                    # Create a temporary DataFrame combining self.df and the new raw bar
                    combined_df = pd.concat([self.df, pd.DataFrame([raw_bar])], ignore_index=True)
                    # Process the combined DataFrame to compute technical indicators
                    processed_combined_df = self._compute_indicators(combined_df)
                    if not processed_combined_df.empty:
                        old_len = len(self.df)
                        # Extract only the last (newly computed) record from the processed DataFrame
                        new_processed_row = processed_combined_df.iloc[[-1]]
                        # Append only the processed last record to self.df
                        self.df = pd.concat([self.df, new_processed_row], ignore_index=True)
                        training_logger.info(
                            f"[Env {self.env_rank}] Appended new processed bar => df length: {old_len} -> {len(self.df)}"
                        )
                        # Update current_step to point to the new latest processed record
                        self.current_step = len(self.df) - 1
        else:
            training_logger.debug(
                f"[Env {self.env_rank}] Skipping aggregator fetch in _next_observation()"
            )

        # ------------------------------------------------
        # (B) Clamp current_step if needed
        # ------------------------------------------------
        if len(self.df) == 0:
            training_logger.warning(
                f"[Env {self.env_rank}] _next_observation called but df is empty. Returning zeros."
            )
            return np.zeros(self.observation_space.shape[0], dtype=np.float32)

        if self.current_step >= len(self.df):
            training_logger.debug(
                f"[Env {self.env_rank}] current_step={self.current_step} exceeds df len={len(self.df)}, clamping step."
            )
            self.current_step = max(0, len(self.df) - 1)

        # ------------------------------------------
        # (C) Build observation from self.df
        # ------------------------------------------
        # Copy the processed self.df and compute indicators again if needed (or rely on self.df already having indicators)
        df_copy = self.df.copy()
        df_with_indicators = self._compute_indicators(df_copy)
        if len(df_with_indicators) == 0:
            training_logger.warning(
                f"[Env {self.env_rank}] After _compute_indicators, we have an empty df. Returning zeros."
            )
            return np.zeros(self.observation_space.shape[0], dtype=np.float32)

        if self.current_step >= len(df_with_indicators):
            training_logger.debug(
                f"[Env {self.env_rank}] current_step={self.current_step} > indicator df len={len(df_with_indicators)}, clamping."
            )
            self.current_step = max(0, len(df_with_indicators) - 1)

        # Update current_step to point to the new latest processed record
        self.current_step = len(self.df) - 1
        current_data = df_with_indicators.iloc[self.current_step]
        features = current_data[FEATURES_TO_SCALE].values

        obs_dict = {}
        # Build the base features
        for i, feat_name in enumerate(FEATURES_TO_SCALE):
            val = float(features[i])
            if feat_name in LOG_TRANSFORM_FEATURES:
                if val <= 0:
                    val = 1e-9
                val = np.log(val)
            obs_dict[feat_name] = val

        # Additional environment-specific fields
        obs_dict["Balance_Ratio"] = self.balance / self.profit_reference
        obs_dict["NetWorth_Ratio"] = self.net_worth / self.profit_reference
        obs_dict["Position_Ratio"] = self.position / self.profit_reference

        # Market phase logic
        phase = 'Sideways'
        adx_val = float(current_data.get('ADX', 0.0))
        if adx_val > 25:
            sma10_val = float(current_data.get('SMA10', 0.0))
            sma50_val = float(current_data.get('SMA50', 0.0))
            phase = 'Bull' if sma10_val > sma50_val else 'Bear'
        obs_dict["Phase_Bull"] = 1.0 if phase == 'Bull' else 0.0
        obs_dict["Phase_Bear"] = 1.0 if phase == 'Bear' else 0.0
        obs_dict["Phase_Sideways"] = 1.0 if phase == 'Sideways' else 0.0

        # Drawdown metrics
        current_drawdown_fraction = (self.peak - self.net_worth) / self.peak if self.peak > 0 else 0.0
        meltdown_threshold = self.max_drawdown
        drawdown_buffer = max(0.0, meltdown_threshold - current_drawdown_fraction)
        obs_dict["Drawdown_Fraction"] = current_drawdown_fraction
        obs_dict["Drawdown_Buffer"] = drawdown_buffer

        # Profit/Loss metrics
        obs_dict["Profit_Percent"] = max(0.0, (self.net_worth - self.profit_reference) / self.profit_reference)
        obs_dict["Loss_Percent"] = max(0.0, (self.profit_reference - self.net_worth) / self.profit_reference)
        obs_dict["Log_Return"] = float(current_data.get("Log_Return", 0.0))

        # Build final observation array
        obs_list = [obs_dict[name] for name in FEATURES_TO_SCALE]
        obs_list += [
            obs_dict["Balance_Ratio"],
            obs_dict["NetWorth_Ratio"],
            obs_dict["Position_Ratio"],
            obs_dict["Phase_Bull"],
            obs_dict["Phase_Bear"],
            obs_dict["Phase_Sideways"],
            obs_dict["Drawdown_Fraction"],
            obs_dict["Drawdown_Buffer"],
            obs_dict["Profit_Percent"],
            obs_dict["Loss_Percent"],
            obs_dict["Log_Return"],
        ]

        obs_array = np.array(obs_list, dtype=np.float32)
        if np.isnan(obs_array).any() or np.isinf(obs_array).any():
            obs_array = np.nan_to_num(obs_array, nan=0.0, posinf=0.0, neginf=0.0)

        self.current_obs_dict = obs_dict  # For debugging/logging in step
        training_logger.debug(
            f"[Env {self.env_rank}] _next_observation(fetch_aggregator={fetch_aggregator}), built obs shape={obs_array.shape}"
        )
        return obs_array

    def reset(self, seed=None, options=None):
        training_logger.info(f"[Env {self.env_rank}] reset() called. df currently has {len(self.df)} rows.")
        if seed is not None:
            # Typically you'd do self.seed(seed) or random.seed(seed), etc.
            # For example:
            random.seed(RANDOM_SEED)
            np.random.seed(RANDOM_SEED)
            torch.manual_seed(RANDOM_SEED)

        # Clear any existing data to avoid duplicate historical data
        self.df = pd.DataFrame()

        prev_data_df = get_data_kite(
            self.kite,
            instrument_token=self.instrument_token,
            days=1,
            interval="15minute"
        )
        if not prev_data_df.empty:
            self.df = pd.concat([prev_data_df, self.df], ignore_index=True)
            main_logger.info(f"Prepopulated historical bars: {len(prev_data_df)}")
        else:
            main_logger.warning("No historical data available for prepopulation.")

        self.balance = self.initial_balance
        self.position = 0
        self.net_worth = self.initial_balance
        self.profit_reference = self.initial_balance
        self.realized_gain = 0.0
        self.current_step = 0
        #self.current_step = len(self.df) - 1 if len(self.df) > 0 else 0
        #self.history = []
        self.prev_net_worth = self.net_worth
        self.last_action = 0.0
        self.peak = self.net_worth
        self.returns_window = []
        self.transaction_count = 0
        self.consecutive_drawdown_steps = 0
        self.reward_history.clear()
        self.cumulative_reward = 0.0
        self._force_termination = False
        #self.final_metrics = None
        initial_obs = np.zeros(self.observation_space.shape, dtype=np.float32)
        print(f"RESET COMPLETE, prev_data_df pre-popu length={len(self.df)}, returning first obs")
        training_logger.info(
            f"[Env {self.env_rank}] reset complete. final df length={len(self.df)}. Returning first observation."
        )
        return initial_obs, {}
        return self._next_observation(fetch_aggregator=False), {}

    def get_final_metrics(self):
        return getattr(self, "last_episode_metrics", {
            "cumulative_reward": 0.0,
            "net_worth": self.initial_balance,
            "balance": self.initial_balance,
            "position": 0,
            "transaction_count": 0,
            "peak": self.initial_balance,
            "history": []
        })

    def get_current_metrics(self):
        return {
            "cumulative_reward": self.cumulative_reward,
            "net_worth": self.net_worth,
            "balance": self.balance,
            "position": self.position,
            "transaction_count": self.transaction_count,
            "peak": self.peak,
            "history": self.history.copy()
        }
    
    def set_force_termination(self, force: bool = True):
        self._force_termination = force
    
    def step(self, action: np.ndarray):
        print(f"ENV STEP CALLED at step={self.current_step}, done=?")

        current_time = datetime.now(pytz.timezone("Asia/Kolkata")).time()
        #cutoff_time = dtime(17, 4) 

        print("Current Time:", current_time)
        print("Cutoff Time (10 mins ahead):", cutoff_time)
        if current_time >= cutoff_time:
            training_logger.info("[Env %s] Current time %s reached cutoff time %s. Terminating episode.", 
                                self.env_rank, current_time, cutoff_time)
            print(f"[Env {self.env_rank}] Current time {current_time} reached cutoff time {cutoff_time}. Terminating episode.")
            self._force_termination = True

        self.last_episode_metrics = {
                "cumulative_reward": sum(entry.get('Reward', 0.0) for entry in self.history),
                "net_worth": self.net_worth,
                "balance": self.balance,
                "position": self.position,
                "transaction_count": self.transaction_count,
                "peak": self.peak,
                "history": self.history.copy()
            }

        if self._force_termination:
            obs = self._next_observation(fetch_aggregator=False)
            #self.final_metrics = self.get_current_metrics()            
            self.last_episode_metrics = {
                "cumulative_reward": sum(entry.get('Reward', 0.0) for entry in self.history),
                "net_worth": self.net_worth,
                "balance": self.balance,
                "position": self.position,
                "transaction_count": self.transaction_count,
                "peak": self.peak,
                "history": self.history.copy()
            }
            self._force_termination = False
            return obs, 0.0, True, True, {}
        
        terminated = False
        training_logger.debug(f"DEBUG step env_rank={self.env_rank}: returning 5 items!")
        training_logger.debug(f"[Env {self.env_rank}] step() called at current_step={self.current_step} with action={action}")
        print(f"[Env {self.env_rank}] step() called at current_step={self.current_step} with action={action}")

        training_logger.debug(
            f"[Env {self.env_rank} step()] action={action} "
            f"type={type(action)} "
            f"shape={(action.shape if hasattr(action, 'shape') else None)}"
        )

        current_obs_array = self._next_observation(fetch_aggregator=False)
        try:
            action_value = float(action[0])
            if action_value > 0 and action_value < self.inference_buy_threshold:
                action_value = 0.0
            elif action_value < 0 and abs(action_value) < self.inference_sell_threshold:
                action_value = 0.0
            assert self.action_space.contains(action), f"[Env {self.env_rank}] Invalid action: {action}"
        except Exception as e:
            training_logger.error(f"[Env {self.env_rank}] Action validation failed: {e}")
            return self._next_observation(fetch_aggregator=False), -1000.0, True, False, {}

        invalid_action_penalty = -0.01

        if self.current_step >= len(self.df):
            terminated = True
            truncated = False
            reward = -1000
            obs = self._next_observation(fetch_aggregator=False)
            self.history.append({
                'Date': None,
                'Close': None,
                'Action': np.nan,
                'Buy_Signal_Price': np.nan,
                'Sell_Signal_Price': np.nan,
                'Net Worth': self.net_worth,
                'Balance': self.balance,
                'Position': self.position,
                'Reward': reward,
                'Trade_Cost': 0.0
            })
            training_logger.error(f"[Env {self.env_rank}] Terminating episode at step {self.current_step} due to data overflow.")
            return obs, reward, terminated, truncated, {}

        current_data = self.df.iloc[self.current_step]
        current_price = float(current_data['Close'])
        current_date = current_data['Date']

        shares_traded = 0
        trade_cost = 0.0
        invalid_act_penalty = 0.0

        net_worth = float(self.balance + self.position * current_price)
        net_worth_change = net_worth - self.prev_net_worth

        stop_loss_triggered = False
        take_profit_triggered = False
        drawdown_triggered = False

        forced_stop_penalty_weight = self.reward_weights.get('forced_stop_penalty_weight', 0.001)
        forced_stop_penalty = 0.0
        current_loss = (self.initial_balance - net_worth) / self.initial_balance if net_worth < self.initial_balance else 0.0

        stop_loss_tiers = [
            {"threshold": 0.0025, "fraction_to_sell": 0.1, "penalty_factor": 1},
            {"threshold": 0.005, "fraction_to_sell": 0.3, "penalty_factor": 1.5},
            {"threshold": 0.0075, "fraction_to_sell": 0.6, "penalty_factor": 2},
            {"threshold": 0.01, "fraction_to_sell": 1.0, "penalty_factor": 2.5},
        ]
        sorted_sl_tiers = sorted(stop_loss_tiers, key=lambda x: x["threshold"], reverse=True)
        for tier in sorted_sl_tiers:
            if current_loss > tier["threshold"] and self.position > 0:
                stop_loss_triggered = True
                tier_penalty = -forced_stop_penalty_weight * current_loss * tier["penalty_factor"]
                forced_stop_penalty += tier_penalty

                fraction_of_shares = math.floor(self.position * tier["fraction_to_sell"])
                if fraction_of_shares == 0 and tier["fraction_to_sell"] < 1.0 and self.position > 0:
                    fraction_of_shares = 1
                if fraction_of_shares > 0:
                    proceeds = fraction_of_shares * current_price * (1 - self.transaction_cost)
                    self.balance += proceeds
                    self.position -= fraction_of_shares
                    self.transaction_count += 1
                    self.net_worth = float(self.balance + self.position * current_price)
                    self.peak = max(self.peak, net_worth)
                if tier.get("fraction_to_sell", 0.0) == 1.0:
                    terminated = True
                break

        net_worth = float(self.balance + self.position * current_price)
        forced_tp_penalty_weight = self.reward_weights.get('forced_tp_penalty_weight', 0.001)
        forced_tp_penalty = 0.0
        current_profit = (net_worth - self.profit_reference) / self.profit_reference if net_worth > self.profit_reference else 0.0

        take_profit_tiers = [
            {"threshold": 0.005, "fraction_to_sell": 0.25, "penalty_factor": 1},
            {"threshold": 0.007, "fraction_to_sell": 0.5, "penalty_factor": 2},
            {"threshold": 0.01,  "fraction_to_sell": 1.0, "penalty_factor": 3},
        ]
        sorted_tp_tiers = sorted(take_profit_tiers, key=lambda x: x["threshold"], reverse=True)
        for tier in sorted_tp_tiers:
            if current_profit > tier["threshold"] and self.position > 0:
                take_profit_triggered = True
                tier_penalty = -forced_tp_penalty_weight * current_profit * tier["penalty_factor"]
                forced_tp_penalty += tier_penalty

                fraction_of_shares = math.floor(self.position * tier["fraction_to_sell"])
                if fraction_of_shares == 0 and tier["fraction_to_sell"] < 1.0 and self.position > 0:
                    fraction_of_shares = 1
                if fraction_of_shares > 0:
                    proceeds = fraction_of_shares * current_price * (1 - self.transaction_cost)
                    self.balance += proceeds
                    self.position -= fraction_of_shares
                    self.transaction_count += 1
                    self.net_worth = float(self.balance + self.position * current_price)
                    self.peak = max(self.peak, self.net_worth)
                    main_logger.critical(
                        f"[TakeProfit] Sold {fraction_of_shares} shares at {current_price:.2f}, proceeds={proceeds:.2f}, "
                        f"new_balance={self.balance:.2f}, new_position={self.position}, new_net_worth={self.net_worth:.2f}"
                    )
                if self.net_worth > self.profit_reference + 500 or self.net_worth > self.profit_reference * 1.01:
                    excess = self.net_worth - self.profit_reference * 1.005
                    new_profit_reference = self.profit_reference
                    cash_out = max(0, self.net_worth - new_profit_reference)
                    
                    main_logger.critical(
                        f"[Trial {getattr(self, 'trial_id', 'N/A')}][Env {self.env_rank}][Ticker={self.ticker}][Step={self.current_step}] "
                        f"TAKE-PROFIT cash-out triggered. old_profit_ref={self.profit_reference:.2f}, net_worth={self.net_worth:.2f}, "
                        f"excess={excess:.2f}, new_profit_ref={new_profit_reference:.2f}, cash_out={cash_out:.2f}"
                    )
                    self.realized_gain += cash_out
                    self.balance -= cash_out
                    self.net_worth = float(self.balance + self.position * current_price)
                    self.profit_reference = new_profit_reference
                    main_logger.critical(
                        f"[Trial {getattr(self, 'trial_id', 'N/A')}][Env {self.env_rank}][Ticker={self.ticker}][Step={self.current_step}] "
                        f"After TAKE-PROFIT cash-out: realized_gain={self.realized_gain:.2f}, balance={self.balance:.2f}, "
                        f"net_worth={self.net_worth:.2f}, profit_reference={self.profit_reference:.2f}"
                    )
                break

        profit_weight = self.reward_weights.get('profit_weight', 1.5)
        sharpe_bonus_weight = self.reward_weights.get('sharpe_bonus_weight', 0.05)
        holding_bonus_weight = self.reward_weights.get('holding_bonus_weight', 0.001)

        profit_reward = (net_worth_change / self.initial_balance) * profit_weight
        log_return = np.log(net_worth / self.prev_net_worth) if self.prev_net_worth > 0 else 0.0

        self.returns_window.append(log_return)
        if len(self.returns_window) > 30:
            self.returns_window.pop(0)
        if self.position == 0:
            self.returns_window = []
        if self.position > 0 and len(self.returns_window) >= 1:
            mean_log_return = np.mean(self.returns_window)
            std_log_return = np.std(self.returns_window) + 1e-9
            sharpe = mean_log_return / std_log_return
            sharpe_bonus = sharpe * self.reward_weights.get('sharpe_bonus_weight', 0.05)
        else:
            sharpe_bonus = 0.0

        self.peak = max(self.peak, net_worth)
        net_worth = float(self.balance + self.position * current_price)
        self.net_worth = net_worth

        current_drawdown = (self.peak - net_worth) / self.peak if self.peak > 0 else 0.0
        drawdown_penalty = 0.0

        if not stop_loss_triggered:
            drawdown_tiers = [
                {"threshold": 0.01, "penalty_factor": 1.0, "liquidate": False},
                {"threshold": 0.015, "penalty_factor": 1.5, "liquidate": True, "fraction_to_sell": 0.5},
                {"threshold": 0.02, "penalty_factor": 2.0, "liquidate": True, "fraction_to_sell": 1.0},
            ]
            base_penalty = -self.some_factor * current_drawdown
            for tier in drawdown_tiers:
                if current_drawdown > tier["threshold"] and self.position > 0:
                    drawdown_penalty -= base_penalty * tier["penalty_factor"]
                    drawdown_triggered = True
                    if tier.get("liquidate", False) and self.position > 0:
                        frac = tier.get("fraction_to_sell", 0.0)
                        if frac > 0:
                            shares_to_sell = math.floor(self.position * frac) if frac < 1.0 else self.position
                            if shares_to_sell > 0:
                                proceeds = shares_to_sell * current_price * (1 - self.transaction_cost)
                                self.balance += proceeds
                                self.position -= shares_to_sell
                                self.transaction_count += 1
                                self.net_worth = float(self.balance + self.position * current_price)
                                self.peak = max(self.peak, net_worth)
                    if tier.get("fraction_to_sell", 0.0) == 1.0:
                        terminated = True
                    break

        net_worth = float(self.balance + self.position * current_price)
        self.net_worth = net_worth

        if any([stop_loss_triggered, take_profit_triggered, drawdown_triggered]) and terminated:
            action_value = 0

        buy_signal_price = np.nan
        sell_signal_price = np.nan

        if action_value > 0:
            investment_amount = self.balance * action_value * self.max_position_size
            shares_to_buy = math.floor(investment_amount / current_price)
            if shares_to_buy == 0:
                one_share_cost = current_price * (1 + self.transaction_cost)
                if one_share_cost <= self.balance:
                    shares_to_buy = 1
            total_cost = shares_to_buy * current_price * (1 + self.transaction_cost)
            if shares_to_buy > 0 and total_cost <= self.balance:
                buy_signal_price = current_price
                self.balance -= total_cost
                self.position += shares_to_buy
                self.transaction_count += 1
                trade_cost = shares_to_buy * current_price * self.transaction_cost
            else:
                invalid_act_penalty = invalid_action_penalty
        elif action_value < 0:
            proportion_to_sell = abs(action_value) * self.max_position_size
            shares_to_sell = math.floor(self.position * proportion_to_sell)
            if shares_to_sell == 0 and self.position > 0:
                shares_to_sell = 1
            if shares_to_sell > 0 and shares_to_sell <= self.position:
                sell_signal_price = current_price
                proceeds = shares_to_sell * current_price * (1 - self.transaction_cost)
                self.position -= shares_to_sell
                self.balance += proceeds
                self.transaction_count += 1
                trade_cost = shares_to_sell * current_price * self.transaction_cost
            else:
                invalid_act_penalty = invalid_action_penalty
        else:
            pass

        net_worth = float(self.balance + self.position * current_price)
        self.net_worth = net_worth

        hold_factor = max(0, 1 - abs(action_value) / 0.1)
        raw_vol = current_data['Volatility']
        vol_thresh = self.reward_weights.get('volatility_threshold', 1.0)
        volatility_factor = 1.0 - np.clip(raw_vol / vol_thresh, 0.0, 1.0)

        mom_thresh_min = self.reward_weights.get('momentum_threshold_min', 30)
        mom_thresh_max = self.reward_weights.get('momentum_threshold_max', 70)
        if mom_thresh_max > mom_thresh_min:
            raw_rsi = current_data['RSI']
            rsi_factor = (raw_rsi - mom_thresh_min) / (mom_thresh_max - mom_thresh_min)
            rsi_factor = np.clip(rsi_factor, 0.0, 1.0)
        else:
            rsi_factor = 0.0

        favorable_hold_factor = hold_factor * volatility_factor * rsi_factor
        if self.position > 0:
            holding_bonus = favorable_hold_factor * holding_bonus_weight
        else:
            holding_bonus = 0.0

        transaction_penalty_weight = self.reward_weights.get('transaction_penalty_weight', 1.0)
        transaction_penalty = -(trade_cost / self.initial_balance) * transaction_penalty_weight

        reward = (
            profit_reward
            + sharpe_bonus
            + forced_stop_penalty
            + forced_tp_penalty
            + drawdown_penalty
            + transaction_penalty
            + holding_bonus
            + invalid_act_penalty
        )
        raw_reward = reward
        self.reward_history.append(raw_reward)
        normalized_reward = float(raw_reward)
        self.cumulative_reward += float(reward)

        self.history.append({
            'Date': current_date,
            'Close': current_price,
            'ticker': self.ticker,
            'env_rank': self.env_rank,
            'Action': action_value,
            'Buy_Signal_Price': buy_signal_price,
            'Sell_Signal_Price': sell_signal_price,
            'Full Worth': self.net_worth + self.realized_gain, 
            'Net Worth': self.net_worth,
            'Balance': self.balance,
            'Realized Gain': self.realized_gain,
            'Position': self.position,
            'Reward': normalized_reward,
            'profit_reward': profit_reward,
            'sharpe_bonus': sharpe_bonus,
            'holding_bonus': holding_bonus,
            'Trade_Cost': trade_cost,
            'cumulative_reward': self.cumulative_reward,
            'forced_stop_penalty': forced_stop_penalty,
            'forced_tp_penalty': forced_tp_penalty,
            'drawdown_penalty': drawdown_penalty,
            'transaction_penalty': transaction_penalty,
            'is_terminated': terminated,
            'stop_loss_triggered': stop_loss_triggered,
            'take_profit_triggered': take_profit_triggered,
            'drawdown_triggered': drawdown_triggered,
            'new_profit_reference': self.profit_reference,
            'invalid_act_penalty': invalid_act_penalty,
            'profit_weight': profit_weight,
            'sharpe_bonus_weight': sharpe_bonus_weight,
            'transaction_penalty_weight': transaction_penalty_weight,
            'holding_bonus_weight': holding_bonus_weight,
            'inference_buy_threshold': self.inference_buy_threshold,
            'inference_sell_threshold': self.inference_sell_threshold,
            'forced_stop_penalty_weight': forced_stop_penalty_weight,
            'forced_tp_penalty_weight': forced_tp_penalty_weight,
            **{f"Obs_{k}": float(v) for k, v in self.current_obs_dict.items()}
        })

        row_data = self.df.iloc[self.current_step].copy()
        redundant_cols = ['Date', 'Close', 'Adj Close', 'Open', 'High', 'Low', 'Volume']
        row_data.drop(labels=redundant_cols, errors='ignore', inplace=True)
        indicator_cols = [
            "SMA10", "SMA50", "RSI", "MACD", "ADX",
            "BB_Upper", "BB_Lower", "Bollinger_Width",
            "EMA20", "VWAP", "Lagged_Return", "Volatility"
        ]
        for col in indicator_cols:
            self.history[-1][col] = row_data[col]

        MIN_STEPS = 10
        if self.current_step >= MIN_STEPS:
            if net_worth <= 0:
                terminated = True
                normalized_reward -= 10.0
                self.final_metrics = self.get_current_metrics()            
            elif self.current_step >= self.max_episode_steps:
                terminated = True
                self.final_metrics = self.get_current_metrics()
            else:
                terminated = terminated
        else:
            terminated = terminated

        truncated = False
        if terminated:
            self.last_episode_metrics = {
                "cumulative_reward": sum(entry.get('Reward', 0.0) for entry in self.history),
                "net_worth": self.net_worth,
                "balance": self.balance,
                "position": self.position,
                "transaction_count": self.transaction_count,
                "peak": self.peak,
                "history": self.history.copy()
            }

        if not terminated:
            self.prev_net_worth = net_worth
            self.current_step += 1

        training_logger.debug(f"[Env {self.env_rank}] Updated current_step: {self.current_step} / {len(self.df)}")
        self.current_step = min(self.current_step, len(self.df) - 1)
        obs = self._next_observation(fetch_aggregator=True)
        return obs, normalized_reward, terminated, truncated, {}

# --------------------------------------------------------------
# PART F: get_data (yfinance) with IST
# --------------------------------------------------------------
import os
import logging
import pandas as pd
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize

def get_data(ticker: str, period: str = "60d", interval: str = "15m") -> pd.DataFrame:
    """
    Fetch intraday data from yfinance for a given ticker and perform technical indicator calculations.
    The resulting DataFrame will include a "Date" column, OHLC, volume, and additional indicator columns.
    """
    logger.info(f"Fetching {interval} data from yfinance for ticker {ticker} over period {period}")
    RESULTS_DIR = Path("./results")
    RESULTS_DIR.mkdir(exist_ok=True, parents=True)
    
    try:
        df = yf.download(ticker, period=period, interval=interval, auto_adjust=False, progress=False)
    except Exception as e:
        logger.error(f"Error fetching data from yfinance for ticker {ticker}: {e}")
        return pd.DataFrame()
    
    if df.empty:
        logger.error(f"No data fetched from yfinance for ticker {ticker}")
        return pd.DataFrame()
    
    df.reset_index(inplace=True)
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = [col[0] for col in df.columns]

    if "Datetime" in df.columns:
        df.rename(columns={"Datetime": "Date"}, inplace=True)

    if "Date" in df.columns and len(df) > 0 and df["Date"].iloc[0] == "Date":
        df = df.iloc[1:]
    
    if "Adj Close" not in df.columns:
        df["Adj Close"] = df["Close"]
    
    for col in ["Date", "Open", "High", "Low", "Close", "Volume"]:
        if col not in df.columns:
            logger.error(f"[get_data] Missing required column '{col}' for {ticker}.")
            return pd.DataFrame()
    
    # Convert to datetime in UTC, then convert to IST
    try:
        df["Date"] = pd.to_datetime(df["Date"], utc=True)
        if df["Date"].isna().all():
            raise ValueError("All Date conversion results are NaT")
        df["Date"] = df["Date"].dt.tz_convert("Asia/Kolkata")
    except Exception as e:
        logger.warning(f"[get_data] Could not convert 'Date' column for {ticker} ({e}). Using integer series instead.")
        df["Date"] = pd.Series(range(len(df)))
    
    df.sort_values("Date", inplace=True)
    df.reset_index(drop=True, inplace=True)

    numeric_cols = ["Open", "High", "Low", "Close", "Adj Close", "Volume"]
    df[numeric_cols] = df[numeric_cols].apply(pd.to_numeric, errors="coerce")

    if len(df) < 5:
        logger.error(f"[get_data] Not enough data points ({len(df)}) for ticker {ticker}. Need >= 200.")
        return pd.DataFrame()
    
    try:
        if interval.endswith("m"):
            sma_short_window = 3
            sma_long_window = 9
            rsi_window = 7
            adx_window = 7
            bollinger_window = 10
            ema_window = 5
        else:
            sma_short_window = 10
            sma_long_window = 50
            rsi_window = 14
            adx_window = 14
            bollinger_window = 20
            ema_window = 20

        from ta import trend, momentum, volatility, volume

        close = df["Close"].squeeze()
        high = df["High"].squeeze()
        low = df["Low"].squeeze()
        vol_series = df["Volume"].squeeze()

        df['Log_Close'] = np.log(df['Close'])
        df['Log_Return'] = df['Log_Close'].diff().fillna(0)

        df["SMA10"] = trend.SMAIndicator(close=close, window=sma_short_window).sma_indicator()
        df["SMA50"] = trend.SMAIndicator(close=close, window=sma_long_window).sma_indicator()
        df["RSI"] = momentum.RSIIndicator(close=close, window=rsi_window).rsi()
        df["MACD"] = trend.MACD(close=close).macd()
        df["ADX"] = trend.ADXIndicator(high=high, low=low, close=close, window=adx_window).adx()
        bollinger = volatility.BollingerBands(close=close, window=bollinger_window, window_dev=2)
        df["BB_Upper"] = bollinger.bollinger_hband()
        df["BB_Lower"] = bollinger.bollinger_lband()
        df["Bollinger_Width"] = bollinger.bollinger_wband()
        df["EMA20"] = trend.EMAIndicator(close=close, window=ema_window).ema_indicator()
        df["VWAP"] = volume.VolumeWeightedAveragePrice(
            high=high, low=low, close=close, volume=vol_series, window=14
        ).volume_weighted_average_price()
        df["Lagged_Return"] = close.pct_change().fillna(0)
        df["Volatility"] = volatility.AverageTrueRange(
            high=high, low=low, close=close, window=adx_window
        ).average_true_range()

        df['HourOfDay'] = df['Date'].dt.hour
        df['MinuteOfHour'] = df['Date'].dt.minute
        df['DayOfWeek'] = df['Date'].dt.dayofweek
        df['Lag_Return_1'] = df['Close'].pct_change(1).fillna(0)
        df['Lag_Return_2'] = df['Close'].pct_change(2).fillna(0)
        df['Volume_Change_1'] = df['Volume'].pct_change(1).fillna(0)
        df['Volume_RollRatio'] = (df['Volume'] / df['Volume'].rolling(5).mean()).fillna(1)
        df['Intraday_Range'] = df['High'] - df['Low']
        df['Intraday_Range_Pct'] = (df['High'] - df['Low']) / (df['Close'] + 1e-9)

        df['MinutesSinceOpen'] = (
            df['Date'] - df['Date'].dt.normalize() - pd.Timedelta("9h30m")
        ).dt.total_seconds() / 60
        df['MinutesSinceOpen'] = df['MinutesSinceOpen'].clip(lower=0)
    except Exception as e:
        logger.error(f"[get_data] Error calculating indicators for {ticker}: {e}")
        return pd.DataFrame()
    
    df.fillna(method="ffill", inplace=True)
    df.fillna(0, inplace=True)
    
    raw_csv_file = RESULTS_DIR / f"data_fetched_{ticker}.csv"
    try:
        df.to_csv(raw_csv_file, index=False)
        logger.info(f"[get_data] Wrote raw CSV for ticker {ticker}: {raw_csv_file}")
    except Exception as e:
        logger.error(f"[get_data] Failed to write raw CSV for {ticker}: {e}")
        return pd.DataFrame()
    
    logger.info(f"[get_data] Successfully fetched & validated data for {ticker}. Final shape: {df.shape}")
    return df

# ----------------------------------------------------------
# PART G: Inference (run_live_inference, main, etc.) in IST
# ----------------------------------------------------------
import os
import logging
import pandas as pd
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import SubprocVecEnv, VecNormalize

log_formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

console_handler = logging.StreamHandler()
console_handler.setFormatter(log_formatter)
logger.addHandler(console_handler)

log_file = RESULTS_DIR / "inference.log"
file_handler = logging.FileHandler(str(log_file))
file_handler.setFormatter(log_formatter)
logger.addHandler(file_handler)

def run_live_inference(model_path: str, vecnormalize_path: str = None):
    """
    1) Create SingleStockTradingEnv for each ticker using live Kite Ticker data.
    2) Wrap environments in a vectorized environment.
    3) Load the pretrained PPO model.
    4) Run inference for a specified duration.
    5) Save or print the results.
    """
    logger.info("Starting live inference run using Kite Ticker live data.")
    
    test_tickers = ["KOTAKBANK", "ITC", "ASIANPAINT", "AXISBANK", "LT", "NTPC", "SBIN"]
    best_params = {
        'learning_rate': 0.00016972542653371844,
        'n_steps': 256,
        'batch_size': 32,
        'gamma': 0.9504072710467327,
        'gae_lambda': 0.8723923253867272,
        'clip_range': 0.22217858436324803,
        'ent_coef': 0.00019794996897039995,
        'vf_coef': 0.14056054512998148,
        'max_grad_norm': 0.7477844238695643,
        'drawdown_penalty_factor': 800.0,
        'stop_loss': 0.87,
        'take_profit': 1.13,
        'transaction_cost': 0.0001,
        'reward_scale': 1.8,
        'max_position_size': 0.8,
        'max_drawdown': 0.065,
        'profit_weight': 960.4438516376347,
        'sharpe_bonus_weight': 45.67422989620618,
        'transaction_penalty_weight': 0.0005354254164585973,
        'holding_bonus_weight': 64.44715250224465,
        'volatility_threshold': 2.3448404146656054,
        'momentum_threshold_min': 41.0464353832542,
        'momentum_threshold_max': 77.53746097203035,
        'hold_threshold': 0.07,
        'inference_buy_threshold': 0.2284828835862186,
        'inference_sell_threshold': 0.4610646015385164,
        'forced_stop_penalty_weight': 400.0,
        'forced_tp_penalty_weight': 1000.0,
        'num_layers': 7,
        'layer_size_0': 128,
        'layer_size_1': 256,
        'layer_size_2': 64,
        'layer_size_3': 64,
        'layer_size_4': 128,
        'layer_size_5': 64,
        'layer_size_6': 128
    }
    
    INITIAL_BALANCE = 100000
    ANNUAL_TRADING_DAYS = 252

    required_columns = ["Date", "Open", "High", "Low", "Close", "Volume"]
    empty_df = pd.DataFrame(columns=required_columns)
    
    envs = []
    for i,ticker in enumerate(test_tickers):
        logger.info(f"Creating live environment for ticker: {ticker}")
        instrument_token = get_instrument_token(ticker, instrument_df)
        if instrument_token is None:
            logger.error(f"Could not find instrument token for ticker {ticker}")
            exit(1)
        logger.info(f"Instrument token for {ticker}: {instrument_token}")       

        env = SingleStockTradingEnv(
            df=empty_df.copy(),
            ticker=ticker,
            kite=kite,
            initial_balance=INITIAL_BALANCE,
            stop_loss=best_params.get('stop_loss'),
            take_profit=best_params.get('take_profit'),
            max_position_size=best_params.get('max_position_size'),
            max_drawdown=best_params.get('max_drawdown'),
            annual_trading_days=ANNUAL_TRADING_DAYS,
            transaction_cost=best_params.get('transaction_cost'),
            env_rank=i,
            some_factor=best_params.get('forced_stop_penalty_weight', 1.0),
            hold_threshold=best_params.get('hold_threshold'),
            reward_weights={
                'reward_scale': best_params.get('reward_scale'),
                'profit_weight': best_params.get('profit_weight'),
                'sharpe_bonus_weight': best_params.get('sharpe_bonus_weight'),
                'transaction_penalty_weight': best_params.get('transaction_penalty_weight'),
                'holding_bonus_weight': best_params.get('holding_bonus_weight'),
                'transaction_penalty_scale': best_params.get('transaction_penalty_weight'),
                'volatility_threshold': best_params.get('volatility_threshold'),
                'momentum_threshold_min': best_params.get('momentum_threshold_min'),
                'momentum_threshold_max': best_params.get('momentum_threshold_max'),
                'forced_stop_penalty_weight': best_params.get('forced_stop_penalty_weight'),
                'forced_tp_penalty_weight': best_params.get('forced_tp_penalty_weight')
            },
            max_episode_steps=1000,
            mode="test",
            inference_buy_threshold=best_params.get('inference_buy_threshold'),
            inference_sell_threshold=best_params.get('inference_sell_threshold')
        )
        envs.append(env)
        logger.info(f"Live environment for ticker {ticker} created successfully.")
    
    if not envs:
        logger.error("No environments available for live inference. Exiting function.")
        return
    
    logger.info("Wrapping environments in a vectorized environment.")
    def make_env(env_obj):
        def _init():
            return env_obj
        return _init
    env_fns = [make_env(e) for e in envs]
    vec_env = DummyVecEnv(env_fns)
    
    if vecnormalize_path and os.path.exists(vecnormalize_path):
        logger.info(f"Loading VecNormalize stats from {vecnormalize_path}")
        vec_env = VecNormalize.load(vecnormalize_path, vec_env)
        vec_env.training = False
        vec_env.norm_obs = True
        vec_env.norm_reward = True
        vec_env.clip_obs = 10000.0
        vec_env.clip_reward = 250000.0
        logger.info("VecNormalize loaded and parameters set to match training.")
    else:
        logger.warning("VecNormalize file not found or not provided. Proceeding without loaded normalization stats.")
    
    if not os.path.exists(model_path):
        logger.error(f"Model file not found at {model_path}. Exiting live inference run.")
        return
    logger.info(f"Loading pretrained PPO model from {model_path}")
    model = PPO.load(model_path, env=vec_env)
    logger.info("PPO model loaded successfully.")
    
    try:
        obs = vec_env.reset()
        logger.info("vec_env.reset() succeeded")
    except Exception as e:
        logger.error(f"vec_env.reset() threw exception: {e}")

    done = [False] * vec_env.num_envs
    logger.info(f"After vec_env.reset(), done={done}")
    steps = 0
    max_steps = 1000 # For demonstration, adjust as needed
    
    logger.info("Starting live inference loop.")
    while not all(done) and steps < max_steps:
        #action, _ = model.predict(obs, deterministic=True)
        logger.info("Calling model.predict() with obs=%s", obs)
        action, _ = model.predict(obs, deterministic=True)
        logger.info("Got action=%s", action)

        obs, rewards, done, infos = vec_env.step(action)        
        steps += 1
        #if steps % 100 == 0:
        logger.info(f"Live inference step {steps}: actions={action}, rewards={rewards}, done={done}")
    logger.info("Live inference loop complete.")
    
    final_metrics_list = vec_env.env_method("get_final_metrics")
    logger.info("Retrieving final metrics from each live environment.")
    for i, ticker in enumerate(test_tickers):
        if i >= len(final_metrics_list):
            break
        fm = final_metrics_list[i]
        net_worth = fm.get("net_worth", None)
        history = fm.get("history", [])
        logger.info(f"Ticker {ticker} final net worth = {net_worth}")
        if history:
            df_history = pd.DataFrame(history)
            out_csv = f"./results/live_inference_history_{ticker}.csv"
            df_history.to_csv(out_csv, index=False)
            logger.info(f"Saved live inference history for ticker {ticker} to {out_csv}")
        else:
            logger.warning(f"No history available for ticker {ticker}.")

def run_inference_for_5_days(model_path: str, vecnormalize_path: str = None):
    run_live_inference(model_path, vecnormalize_path)


def main():
    logger.info("Starting main live inference process using Kite Ticker live data.")
    MODEL_PATH = "./results/ppo_final_model.zip"
    VECNORM_PATH = "./results/vec_normalize.pkl"

    # 1) Acquire a fresh access token via TOTP
    token = get_access_token()
    kite.set_access_token(token)

    # 2) As a quick test, see if we can retrieve the user's profile
    print("User Profile:")
    print(kite.profile())

    # 3) Run the actual 5-day inference logic
    run_inference_for_5_days(model_path=MODEL_PATH, vecnormalize_path=VECNORM_PATH)

if __name__ == "__main__":
    main()
